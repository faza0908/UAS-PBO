/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package penjualan;

/**
 *
 * @author asus
 */
public class Penjualan {

    public static void main(String[] args) {
        System.out.println("Hello World!");
    }
}
